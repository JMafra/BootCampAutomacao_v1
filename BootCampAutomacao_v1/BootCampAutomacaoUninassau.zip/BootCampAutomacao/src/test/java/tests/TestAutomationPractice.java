package tests;

import static org.junit.Assert.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import actions.CreateAccountAction;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import utils.Constants;
import utils.DriveContext;

public class TestAutomationPractice {
	
	protected WebDriver driver; 
	protected CreateAccountAction account;
	

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testCriarContaUsuario() {
		System.setProperty("webdriver.chrome.driver", Constants.PATH_CHROMEDRIVER);
		driver = new ChromeDriver();
		driver.get("http://automationpractice.com/");
		driver.manage().window().maximize();
		DriveContext.setDriver(driver);
		account = new CreateAccountAction();
		account.clicarSignIn();
		account.preecherEmail("bootcamp12@gmail.com");
		account.clicarCreateAccount();
		account.clicarTitle();
		account.preencherFirstName("Juliana");
		account.preencherLastName("Mafra");
		account.preencherPassword("12345");
		account.selecionarDay("5");
		account.selecionarMonth("6");
		account.selecionarYear("2000");	
		account.preencherCompany("Uninassau");
		account.preencherAddress01("Rua Joaquim Nabuco");
        account.preencherAddress02("220");
        account.preencherCity("Recife");
        account.selecionarState("California");
        account.preencherPostCode("55555");
        account.preencherAditionalInformation("informacao adicional");
        account.preencherPhone("8888-9988");
        account.preencherMobilePhone("9999-8888");
        account.preencherReference("referencia qualquer");
        account.clicarRegister();
        account.validarUsuario("Juliana Mafra"); 
        
	}
	
	
	

	@After
	public void tearDown() throws Exception {
	}


}
