package actions;

import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.CreateAccountPage;
import utils.DriveContext;

public class CreateAccountAction extends CreateAccountPage{
	
	protected WebDriverWait wait;
	
	public CreateAccountAction() {
		wait = new WebDriverWait(DriveContext.getDriver(), 10);
		
	}
	
	public void clicarSignIn() {
		wait.until(ExpectedConditions.elementToBeClickable(linkSingIn)).click();
	}
	
	public void preecherEmail(String email) {
		wait.until(ExpectedConditions.visibilityOf(txtEmail)).sendKeys(email);
	}
	
	
	public void clicarCreateAccount() {
		wait.until(ExpectedConditions.elementToBeClickable(btCreateAccount)).click();
	}
	
	public void clicarTitle() {
		wait.until(ExpectedConditions.elementToBeClickable(radioTitle)).click();
	}
	
	public void preencherFirstName(String name) {
		wait.until(ExpectedConditions.visibilityOf(txtFirstName)).sendKeys(name);
	}
	
	public void preencherLastName(String lastName) {
		wait.until(ExpectedConditions.visibilityOf(txtLasttName)).sendKeys(lastName);
	}
	
	public void preencherPassword(String password) {
		wait.until(ExpectedConditions.visibilityOf(txtPassword)).sendKeys(password);
	}
	
	public void selecionarDay(String day) {
		Select cbDay = new Select(cbDays);
		cbDay.selectByValue(day);
		
	}
	
	public void selecionarMonth(String month) {
		Select cbMontth = new Select(cbMonths);
		cbMontth.selectByValue(month);
		
	}	
	
	public void selecionarYear(String year) {
		Select cbYear = new Select(cbYears);
		cbYear.selectByValue(year);
		
	}
	
	public void preencherCompany(String company) {
		wait.until(ExpectedConditions.visibilityOf(txtCompany)).sendKeys(company);
	}
	
	public void preencherAddress01(String address1) {
		wait.until(ExpectedConditions.visibilityOf(txtAddress1)).sendKeys(address1);
	}
	
	public void preencherAddress02(String address2) {
		wait.until(ExpectedConditions.visibilityOf(txtAddress2)).sendKeys(address2);
	}
	
	public void preencherCity(String city) {
		wait.until(ExpectedConditions.visibilityOf(txtCity)).sendKeys(city);
	}
	
	public void selecionarState(String state) {
		Select cbState2 = new Select(cbState);
	//	cbState2.selectByValue(state);
		cbState2.selectByVisibleText(state);
		
	}
	
	public void preencherPostCode(String postCode) {
		wait.until(ExpectedConditions.visibilityOf(txtPostCode)).sendKeys(postCode);
	}
	
	public void preencherAditionalInformation(String aditional) {
		wait.until(ExpectedConditions.visibilityOf(txtOther)).sendKeys(aditional);
	}
	
	public void preencherPhone(String phone) {
		wait.until(ExpectedConditions.visibilityOf(txtPhone)).sendKeys(phone);
	}
	
	public void preencherMobilePhone(String mobilePhone) {
		wait.until(ExpectedConditions.visibilityOf(txtMobilePhone)).sendKeys(mobilePhone);
	}
	
	public void preencherReference(String reference) {
		wait.until(ExpectedConditions.visibilityOf(txtReferenc)).sendKeys(reference);
	}
	
	public void clicarRegister() {
		wait.until(ExpectedConditions.elementToBeClickable(btRegister)).click();
	}
	
	public void validarUsuario(String nome) {
		Assert.assertTrue(nome.equals(lblUser.getText()));
	}

}
