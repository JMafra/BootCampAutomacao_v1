package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utils.DriveContext;

public class CreateAccountPage {
	
	public CreateAccountPage() {
		 PageFactory.initElements(DriveContext.getDriver(), this);
	}
	
	
	@FindBy(how= How.LINK_TEXT, using ="Sign in")			
	protected WebElement linkSingIn;
	
	
	@FindBy(how= How.ID, using ="email_create")			
	protected WebElement txtEmail;
	
	@FindBy(how= How.ID, using ="SubmitCreate")			
	protected WebElement btCreateAccount;
	
	
	@FindBy(how= How.ID, using ="id_gender2")			
	protected WebElement radioTitle;
	
	@FindBy(how= How.ID, using ="customer_firstname")			
	protected WebElement txtFirstName;
	
	@FindBy(how= How.ID, using ="customer_lastname")			
	protected WebElement txtLasttName;
	
	@FindBy(how= How.ID, using ="passwd")			
	protected WebElement txtPassword;
	
	
	@FindBy(how= How.ID, using ="days")			
	protected WebElement cbDays;
	
	@FindBy(how= How.ID, using ="months")			
	protected WebElement cbMonths;
	
	@FindBy(how= How.ID, using ="years")			
	protected WebElement cbYears;
	
	@FindBy(how= How.ID, using ="newsletter")			
	protected WebElement ckNewsletter;
	
	@FindBy(how= How.ID, using ="optin")			
	protected WebElement ckPartners;
	
	
	@FindBy(how= How.ID, using ="company")			
	protected WebElement txtCompany;
	
	@FindBy(how= How.ID, using ="address1")			
	protected WebElement txtAddress1;
	
	@FindBy(how= How.ID, using ="address2")			
	protected WebElement txtAddress2;
	
	@FindBy(how= How.ID, using ="city")			
	protected WebElement txtCity;
	
	@FindBy(how= How.ID, using ="id_state")			
	protected WebElement cbState;
	
	@FindBy(how= How.ID, using ="postcode")			
	protected WebElement txtPostCode;
	
	
	@FindBy(how= How.ID, using ="id_country")			
	protected WebElement cbCountry;
	
	@FindBy(how= How.ID, using ="other")			
	protected WebElement txtOther;
	
	@FindBy(how= How.ID, using ="phone")			
	protected WebElement txtPhone;
	
	@FindBy(how= How.ID, using ="phone_mobile")			
	protected WebElement txtMobilePhone;
	
	@FindBy(how= How.ID, using ="alias")			
	protected WebElement txtReferenc;
	
	@FindBy(how= How.ID, using ="submitAccount")			
	protected WebElement btRegister;
	
	@FindBy(how= How.XPATH, using ="//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a/span")			
	protected WebElement lblUser;
	
	

}
