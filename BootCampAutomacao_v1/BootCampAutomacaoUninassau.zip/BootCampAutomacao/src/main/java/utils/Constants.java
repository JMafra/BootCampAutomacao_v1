package utils;

public class Constants {
	
	public static final  String PATH_CHROMEDRIVER = "src\\main\\resources\\chromedriver.exe";

}
